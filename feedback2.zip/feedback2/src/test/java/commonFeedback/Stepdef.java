package commonFeedback;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	
	@Given("^feedback tab in product page$")
	public void feedback_tab_in_product_page() throws Throwable {
	    
	}

	@When("^feedback form is displayed$")
	public void feedback_form_is_displayed() throws Throwable {
	    
	}

	@Then("^customer can give feedback$")
	public void customer_can_give_feedback() throws Throwable {
	  
	}

	@Given("^Customer feedback$")
	public void customer_feedback() throws Throwable {
	 
	}

	@When("^Admin receives the common feedback$")
	public void admin_receives_the_common_feedback() throws Throwable {
	   
	}

	@Then("^Admin directs the feedback to direct merchant or third party merchant$")
	public void admin_directs_the_feedback_to_direct_merchant_or_third_party_merchant() throws Throwable {
	  
	}

	@Given("^Merchant response$")
	public void merchant_response() throws Throwable {
	 
	}

	@When("^Admin receives the merchant response$")
	public void admin_receives_the_merchant_response() throws Throwable {
	  
	}

	@Then("^Admin redirects it to customer$")
	public void admin_redirects_it_to_customer() throws Throwable {
	}


	

}
