package com.cap.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.model.FeedBack;


@Repository("feedbackDao")
public interface FeedBackDao extends JpaRepository<FeedBack,Integer> {

	
}
