package org.cap.service;

import java.util.List;

import org.cap.model.Account;

public interface IAccountSevice {

void createAccount(Account account);

public List<Account> getAllAccounts(int custId);

List<Account> getAccountWithBalance(int custId);

}
