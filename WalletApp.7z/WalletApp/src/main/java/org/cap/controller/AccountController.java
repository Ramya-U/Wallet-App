package org.cap.controller;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Login;
import org.cap.model.Transaction;
import org.cap.service.IAccountSevice;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	@Autowired
private ILoginService loginService;
	
	@Autowired
	private IAccountSevice accountService;
	
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("customerId") String customerId,
			@RequestParam("customerPwd") String customerPwd,
			HttpSession session) {
		
		Integer custId=Integer.parseInt(customerId);
		
		
		if(loginService.validateLogin(custId, customerPwd)) {
			//Store CustId into the session object
			session.setAttribute("custId", custId);
			
			String custName=loginService.getCustomerName(custId);
			map.put("custName", custName);
			
			return "main";
			
			
		}
		
		return "redirect:/";
	}
	
	
	
	@RequestMapping("/createAccount")
	public String showCreateDetails(ModelMap map) {
			map.put("account", new Account());
			return "createAccount";
			
	}
	
	@RequestMapping("/withdraw")
	public String showTransaction(ModelMap map, HttpSession session) {
	
			Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
			List<Account> accounts=accountService.getAllAccounts(custId);
			map.put("transaction", new Transaction());
			map.put("accounts", accounts);
			return "deposit";
			
		} 
	
	
	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session,
			@ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId=Integer.parseInt(session.getAttribute("custId").toString());
		
		Customer customer= loginService.findCustomer(customerId);
		account.setCustomer(customer);
		account.setStatus("active");
		accountService.createAccount(account);
		
		return "redirect:createAccount";
	}
	
	
	
	

	@RequestMapping("/showBalance")
	public String showBalanceDetails(ModelMap map,
			HttpSession session) {
		
		Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts= accountService.getAccountWithBalance(custId);
		
		map.put("accounts", accounts);
		
		return "showBalance";
	}
	
	
		
		
	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "deposit";
	}
	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return  "withdraw";
	}
	@RequestMapping("/fundTransfer")
	public String showFundTransfer() {
	return "fundTransfer";	
	}
	@RequestMapping("/printTransactions")
	public String printTransactions() {
		return "printTransactions";
	}
	@RequestMapping("/logOut")
	public String logOut(HttpSession session) {
		session.invalidate();
		return "redirect:/";
		
	}
	
	
}
