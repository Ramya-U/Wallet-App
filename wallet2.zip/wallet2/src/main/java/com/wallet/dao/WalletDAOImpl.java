package com.wallet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.runner.Request;

import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public class WalletDAOImpl implements WalletDAO {
Customer customer=new Customer();
Logger logger=Logger.getRootLogger();
	
	public WalletDAOImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

@SuppressWarnings("resource")
@Override
	public Integer createAccount(Customer request) throws WalletException {
	Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
	
	PreparedStatement preparedStatement=null;		
	ResultSet resultSet = null;
	
	int accountNo=0;
	
	int queryResult=0;
	try
	{		
		preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

		preparedStatement.setString(1,request.getName());
		preparedStatement.setString(2, request.getAge());
		preparedStatement.setString(3, request.getAccountType());
		preparedStatement.setString(4, request.getMobileNo());
		preparedStatement.setString(5, request.getEmail());
		preparedStatement.setDouble(6, request.getBalance());
				
		queryResult=preparedStatement.executeUpdate();
	
		preparedStatement = connection.prepareStatement(QueryMapper.ACCOUNTNO_QUERY_SEQUENCE);
		resultSet=preparedStatement.executeQuery();

		if(resultSet.next())
		{
			accountNo=resultSet.getInt(1);
					
		}

		if(queryResult==0)
		{
			logger.error("Insertion failed ");
			throw new WalletException("Inserting customer details failed ");

		}
		else
		{
			logger.info("Customer details added successfully:");
			return accountNo;
		}
	 }
	catch(SQLException sqlException)
	{
		logger.error(sqlException.getMessage());
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
	
}
	
	
/*
	@Override
	public boolean checkAccountNo(Integer accountNo) throws WalletException {
Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
			PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.CHECK_QUERY);
			ResultSet result=preparedStatement.executeQuery();
			return result;
	}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
			

	}*/
	@SuppressWarnings("resource")
	@Override
	public double deposit(double b1, Integer getAccountNo) throws WalletException {
		
		Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		double balance=0;
		
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.DEPOSIT_QUERY);
			preparedStatement.setDouble(1,b1);
			preparedStatement.setInt(2,getAccountNo);
			queryResult=preparedStatement.executeUpdate();
			 
			 preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			 preparedStatement.setInt(1,getAccountNo);
			resultSet=preparedStatement.executeQuery();

			resultSet.next();
			balance=resultSet.getDouble("balance");
		
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Deposition failed ");

			}
			else
			{
				logger.info("Deposited successfully:");
				return balance;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log or Invalid account Number");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
		
	}

	@SuppressWarnings("resource")
	@Override
	public double withdraw(double b1, Integer getAccountNo) throws WalletException {
	
		
	Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		double balance=0;
		
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.WITHDRAW_QUERY);
			preparedStatement.setDouble(1,b1);
			preparedStatement.setInt(2,getAccountNo);
			queryResult=preparedStatement.executeUpdate();
			 
			 preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			 preparedStatement.setInt(1,getAccountNo);
			resultSet=preparedStatement.executeQuery();

			resultSet.next();
			balance=resultSet.getDouble("balance");
		
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Deposition failed ");

			}
			else
			{
				logger.info("Deposited successfully:");
				return balance;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log or Invalid account Number");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	
	}

	@Override
	public double showBalance(Integer accountNo) throws WalletException {
	
Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
	try
		{		
		preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
		preparedStatement.setInt(1,accountNo);
        
	    resultSet=preparedStatement.executeQuery();

		resultSet.next();
		double rs=resultSet.getDouble("balance");
				
		return rs;

	 }
	catch(SQLException sqlException)
	{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log or account number validation fails");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
		
	}
	



	 
	}



