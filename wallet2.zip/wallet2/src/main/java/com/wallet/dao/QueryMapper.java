package com.wallet.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO WalletDetails VALUES(accountNo_sequence.NEXTVAL,?,?,?,?,?,?)";
	public static final String ACCOUNTNO_QUERY_SEQUENCE="SELECT accountNo_sequence.CURRVAL FROM DUAL";
    public static final String SELECT_QUERY="SELECT balance from WALLETDETAILS WHERE account_No=?";
   public static final String DEPOSIT_QUERY="update WalletDetails set balance = balance + ? where account_No=?";
    public static final String WITHDRAW_QUERY="update WalletDetails set balance = balance - ? where account_No=?";
}
