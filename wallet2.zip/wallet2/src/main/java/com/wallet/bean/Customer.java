package com.wallet.bean;

public class Customer {
private String name;
private String age;
private String accountType;
private String mobileNo;
private String email;
private double balance;
private Integer accountNo;

public Customer() {
	super();
}

public Customer(String name, String age, String accountType, String mobileNo, String email, double balance,
		Integer accountNo) {
	super();
	this.name = name;
	this.age = age;
	this.accountType = accountType;
	this.mobileNo = mobileNo;
	this.email = email;
	this.balance = balance;
	this.accountNo = accountNo;
}


public double getBalance() {
	return balance;
}

public void setBalance(double d) {
	this.balance = d;
}

public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}


@Override
public String toString() {
	return "Customer [name=" + name + ", age=" + age + ", accountType=" + accountType + ", mobileNo=" + mobileNo
			+ ", email=" + email + ", balance=" + balance + ", accountNo=" + accountNo + "]";
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(Integer accountNo) {
	this.accountNo = accountNo;
}


}