package com.wallet.service;

import com.wallet.dao.WalletDAOImpl;
import com.wallet.bean.Customer;
import com.wallet.dao.WalletDAO;
import com.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService {
WalletDAO walletDAO=new WalletDAOImpl();

WalletDAO walletDao;


public WalletServiceImpl() {
	walletDao=new WalletDAOImpl();	
}

	@Override
	public Integer createAccount(Customer request) throws WalletException {
		
		return walletDAO.createAccount(request);
	}
	@Override
	public boolean validateCustomer(Customer request) throws WalletException {
		// TODO Auto-generated method stub
		if(validateName(request.getName())&&validateMobile(request.getMobileNo())&&validateEmail(request.getEmail())) {
			return true;
		}
		return false;
	}
	private boolean validateMobile(String mobileNo)throws WalletException{
		if(mobileNo.isEmpty()||mobileNo==null) {
			throw new WalletException("Mobile number mandatory");
		}
		else {
			if(!mobileNo.matches("\\d{10}")) {
				throw new  WalletException("Mobile number should contain 10 characters");
			}
		}
		return true;
	}
	private boolean validateEmail(String email)throws  WalletException{
		if(!email.matches("[A-Za-z0-9_]+@[a-z]+\\.com")) {
			throw new  WalletException("Please enter valid email id");
		}
		return true;
	}
	private boolean validateName(String name)throws WalletException{
		if(name.isEmpty()||name==null) {
			throw new WalletException("Employee name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new WalletException("Name should start with capital letter followed by minimum characters");
			}
		}
		return true;
	}

	@Override
	public double showBalance(Integer accountNo) throws WalletException {
		return walletDAO.showBalance(accountNo);
		
	}
	/*@Override
	public boolean checkAccountNo(Integer accountNo) throws WalletException {
		
		return walletDAO.checkAccountNo(accountNo);
	}*/
	@Override
	public double deposit(double b1, Integer getAccountNo) throws WalletException {
		// TODO Auto-generated method stub
		return walletDAO.deposit(b1,getAccountNo);
	}
	@Override
	public double withdraw(double b1, Integer getAccountNo) throws WalletException {
		// TODO Auto-generated method stub
		return walletDAO.withdraw(b1,getAccountNo); 
		
	}
	
}
	