package org.cap.feedbackRest.controller;


import java.util.List;

import org.cap.feedbackRest.model.FeedBack;
import org.cap.feedbackRest.service.FeedBackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/api/v1")
public class FeedbackController {
	 @Autowired
		private FeedBackService feedbackservice;
		@GetMapping("/comment")
		public ResponseEntity<List<FeedBack>> getAllComments(){
			List<FeedBack> comment= feedbackservice.getAll();
			if(comment.isEmpty()||comment==null)
				return new ResponseEntity("Sorry!  details not available!",HttpStatus.NOT_FOUND);
			return new ResponseEntity<List<FeedBack>>(comment,HttpStatus.OK);
		}
		

		@PostMapping("/comment")
		public ResponseEntity<FeedBack> createPilot(@RequestBody FeedBack comment){
			feedbackservice.save(comment);
			return new ResponseEntity<FeedBack>(comment,HttpStatus.OK);
		}
	
		}



