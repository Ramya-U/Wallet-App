package org.cap.feedbackRest.DAO;

import org.cap.feedbackRest.model.FeedBack;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("feedbackdao")
public interface FeedBackDAO extends JpaRepository<FeedBack, Integer>{

}
