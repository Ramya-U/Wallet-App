package org.cap.feedbackRest.service;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.feedbackRest.DAO.FeedBackDAO;
import org.cap.feedbackRest.model.FeedBack;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("feedbackservice")
public class FeedBackServiceImpl implements FeedBackService{

	@Autowired
private FeedBackDAO feedbackdao;
	

	@Override
	public List<FeedBack> getAll() {
		return feedbackdao.findAll();
	
	}

	@Override
	public void save(FeedBack comment) {
		feedbackdao.save(comment);
		
	}

}
