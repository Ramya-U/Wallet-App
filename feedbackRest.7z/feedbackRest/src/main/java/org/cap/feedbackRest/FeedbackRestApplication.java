package org.cap.feedbackRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackRestApplication.class, args);
	}
}
