package com.wallet.bean;

public class Account {
private static int minbalance=500;
private static long count=3261434;

private double balance;
private long accId;
public static int getMinbalance() {
	return minbalance;
}
public static void setMinbalance(int minbalance) {
	Account.minbalance = minbalance;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}

public long getAccId() {
	return accId;
}
public void setAccId(long accId) {
	this.accId = accId;
}
public void getAccId(long accId) {
	this.accId = accId;
}
public Account(long accId, double balance) {
	super();

	this.balance = balance;
}
public Account() {
	count++;
	accId=count;
}

}

