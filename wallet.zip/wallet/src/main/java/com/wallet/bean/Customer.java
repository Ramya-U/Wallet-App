package com.wallet.bean;

public class Customer {
private String name;
private String age;
private String accountType;
private String mobileNo;
private String email;
private Double balance;
private long accountNo;

public Customer() {
	super();
}

public Customer(String name, String age, String accountType, String mobileNo, String email, Double balance,
		long accountNo) {
	super();
	this.name = name;
	this.age = age;
	this.accountType = accountType;
	this.mobileNo = mobileNo;
	this.email = email;
	this.balance = balance;
	this.accountNo = accountNo;
}


public Double getBalance() {
	return balance;
}

public void setBalance(Double balance) {
	this.balance = balance;
}

public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}


@Override
public String toString() {
	return "Customer [name=" + name + ", age=" + age + ", accountType=" + accountType + ", mobileNo=" + mobileNo
			+ ", email=" + email + ", balance=" + balance + ", accountNo=" + accountNo + "]";
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}


}