package com.wallet.db;

import java.util.HashMap;


import com.wallet.bean.Customer;


public class WalletDB {
	public static HashMap<Long, Customer> getCustomerMap(){
		return customerMap;
	}
private static HashMap<Long, Customer> customerMap=new HashMap<Long,Customer>();
static {
	customerMap.put((long)56789023, new Customer("kaya","21","savings","7708158541","kaya@gmail.com",12000.50,(long)56789023));
	customerMap.put((long) 32456780, new Customer("diya","22","current","7704158541","diya@gmail.com",15000.25,(long) 32456780));
	customerMap.put((long) 10034590, new Customer("maya","23","savings","7708148541","maya@gmail.com",20000.50,(long) 10034590));
	customerMap.put((long) 10041089, new Customer("raya","24","savings","7708658541","raya@gmail.com",5000.00,(long) 10041089));
}

}

