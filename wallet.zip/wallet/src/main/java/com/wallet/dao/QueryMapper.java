package com.wallet.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO WalletDetails VALUES(accountNo_sequence.NEXTVAL,?)";
	public static final String ACCOUNTNO_QUERY_SEQUENCE="SELECT accountNo_sequence.CURRVAL FROM DUAL";

}
/******************TABLESCRIPT*******************
CREATE TABLE WalletDetails(
account_No LONG,
customer_name VARCHAR2(20)
);

CREATE SEQUENCE accountNo_sequence;

************************************************/