package com.wallet.dao;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Optional;


import com.wallet.bean.Customer;
import com.wallet.db.WalletDB;
import com.wallet.exception.WalletException;

public class WalletDAOImpl implements WalletDAO {
	static HashMap<Long,Customer> custMap=WalletDB.getCustomerMap();
	@Override
	public long createAccount(Customer request) throws WalletException {
		try {
			Optional<Long>id=custMap.keySet().stream().max(new Comparator<Long>() {

				@Override
				public int compare(Long x, Long y) {
				
					return x>y?1:x<y?-1:0;
				}
				
			});
			
			long reqId=id.get()+1;
			request.setAccountNo(reqId);
			custMap.put(request.getAccountNo(), request);
			return request.getAccountNo();
		}
		catch(Exception e) {
			throw new WalletException(e.getMessage());
		}
	}
	
	@Override
	public double showBalance(long accountNo) throws WalletException {
		try{
			Customer customer=custMap.get(accountNo);
			return customer.getBalance();
		}catch(Exception ex) {
			throw new WalletException(ex.getMessage());
		}

	}

	
	@Override
	public boolean checkAccountNo(long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Customer customer=custMap.get(accountNo);
			if(customer==null) {
				throw new WalletException("Customer with the given account number " +accountNo+"not available");
			}
			return true;
		}catch(Exception ex) {
		throw new WalletException(ex.getMessage());
	}

	}
	@Override
	public double deposit(double b1, long getAccountNo) throws WalletException {
		// TODO Auto-generated method stub
		Customer customer=custMap.get(getAccountNo);
		double balance=customer.getBalance();
		customer.setBalance(b1+balance);
		
		return customer.getBalance();
	}

	@Override
	public double withdraw(double b1, long getAccountNo) {
		// TODO Auto-generated method stub
		Customer customer=custMap.get(getAccountNo);
		double balance=customer.getBalance();
		customer.setBalance(balance-b1);
		
		return customer.getBalance();
	
	}
	
}

	



