package com.wallet.dao;


import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public interface WalletDAO {
	long createAccount(Customer request)throws WalletException;
	public double showBalance (long accountNo) throws WalletException;
	boolean checkAccountNo(long accountNo)throws WalletException;
	double deposit(double b1, long getAccountNo)throws WalletException;
	double withdraw(double b1, long getAccountNo)throws WalletException;
}

