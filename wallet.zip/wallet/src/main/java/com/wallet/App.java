package com.wallet;
import java.util.InputMismatchException;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;

	public class App 
	{
		   
		static WalletService walletService = null;
		static WalletServiceImpl walletServiceImpl = null;
		static Logger logger = Logger.getRootLogger();
	/*	WalletService walletService=new WalletServiceImpl();*/
		Scanner scan=new Scanner(System.in);
	    public static void main( String[] args )
	    {
	    	Scanner scan=new Scanner(System.in);
	    	PropertyConfigurator.configure("resources//log4j.properties");
			Customer request= null;
	    	App a=new App();
	    	Long accountNo = null;
	        String option=null;
	        while(true)
	        {
	        	System.out.println("------Wallet Application---------");
	        	System.out.println("1) Create an account");
	        	System.out.println("2) Show balance");
	        	System.out.println("3) Deposit");
	        	System.out.println("4) Withdraw");
	        	System.out.println("5) Fund Transfer");
	        	System.out.println("6) Print Transactions");
	        	System.out.println("7) Exit");
	        	System.out.println("Choose an option");
	        	option=scan.nextLine();
	        	switch(option) {
	        	case "1":
	        		/*a.createAccount();*/
	        		while (request == null) {
						request = populateCustomer();
					}
					try {
						accountNo = walletService.createAccount(request);
						System.out.println("Employee details  has been successfully registered ");
						System.out.println("Employee  ID Is: "  +accountNo);

					} catch (WalletException walletException) {
						logger.error("exception occured", walletException);
						System.out.println("ERROR : "
								+ walletException.getMessage());
					} finally {
						accountNo = null;
						walletService = null;
						request = null;
					}
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}
			}
		/*	catch(InputMismatchException e){
				scan.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}*/
		}// end of while
	


	private static Customer populateCustomer() {

		// Reading and setting the values for the donorBean
		Scanner scan=new Scanner(System.in);
		Customer request = new Customer();
		System.out.println("\n Enter Details");
        System.out.println("Enter employee name: ");
		request.setName(scan.next());
		System.out.println("Enter the AccountType(Savings/Current)");
		request.setAccountType(scan.next());
		System.out.println("Enter the Age");
		request.setAge(scan.next());
		System.out.println("Enter the MobileNumber");
        request.setMobileNo(scan.next());
        System.out.println("Enter the email Id");
        request.setEmail(scan.next());

		walletServiceImpl = new WalletServiceImpl();

		try {
			// Validate
			walletServiceImpl.validateCustomer(request);
			return request;
		} catch (WalletException walletException) {
			logger.error("exception occured", walletException);
			System.err.println("Invalid data:");
			System.err.println(walletException.getMessage()
					+ " \n Try again..");
			System.exit(0);

		}
		return null;

	}


	        	/*	break;
	        	case "2":
	        		a.showBalance();
	        		break;
	        	case "3":
	        		a.deposit();
	        		break;
	        	case "4":
	        		a.withdraw();
	        		break;
	        	case "5":
	        		a.transferFund();
	        		break;
	        	case "6":
	        		a.printTransactions();
	        		break;
	        	case "7":
	        		System.exit(0);
	        		default:
	        			System.err.println("Invalid option choose from given");
	        			break;
	        			}
	    }*/
		/*public void transferFund() {
			System.out.println("Enter the source account number");
			String acc=scan.nextLine();
			System.out.println("Enter the destination account number");
			String acc1=scan.nextLine();
			try {
				long a=Integer.parseInt(acc);
				boolean result=walletService.checkAccountNo(a);
				long a1=Integer.parseInt(acc1);
				boolean result1=walletService.checkAccountNo(a1);
				if(result && result1) {
					System.out.println("Enter the amount to be transferred");
					String amt=scan.nextLine();
					double b2=Double.parseDouble(amt);
					double newBalance=walletService.withdraw(b2,a);
					double newBalance1=walletService.deposit(b2,a1);
					System.out.println("The updated balance in source account is"+newBalance);
					System.out.println("The updated balance in destination account is"+newBalance1);
				}
			}catch(WalletException e) {
				System.out.println();
				System.out.println("An error occurred"+e.getMessage());
				System.out.println();
			}
		
		}
		public void printTransactions() {
			System.out.println("The recent transaction done are:");
			  App a=new App();
			  a.showBalance();
			  
			
		}
		
		public void withdraw() {
			System.out.println("Enter the account Number");
			String acc=scan.nextLine();
			try {
				long a=Integer.parseInt(acc);
				boolean result=walletService.checkAccountNo(a);
				System.out.println("Valid details");
				if(result) {
					System.out.println("Enter the amount to be Withdrawn");
					String b1=scan.nextLine();
					double b2=Double.parseDouble(b1);
					double newBalance=walletService.withdraw(b2,a);
					System.out.println("The updated balance is"+newBalance);
			}
		}catch(WalletException e) {
			System.out.println();
			System.out.println("An error occurred"+e.getMessage());
			System.out.println();
		}
		}
		public void deposit() {
		System.out.println("Enter the account Number");
		String acc=scan.nextLine();
		try {
			long a=Integer.parseInt(acc);
			boolean result=walletService.checkAccountNo(a);
			System.out.println("Valid details");
			if(result) {
				System.out.println("Enter the amount to be deposited");
				String b1=scan.nextLine();
				double b2=Double.parseDouble(b1);
				double newBalance=walletService.deposit(b2,a);
				System.out.println("The updated balance is"+newBalance);
			}
		}catch(Exception e) {
			System.out.println();
			System.out.println("An error occurred"+e.getMessage());
			System.out.println();
		}
		}
		    
		
    	public void showBalance() {
			System.out.println("Enter the Account number to view balance: ");
			String acc=scan.nextLine();
			try 
			{
				long a=Integer.parseInt(acc);
				boolean result=walletService.checkAccountNo(a);
				System.out.println("valid details");
				if(result) {
					double d= walletService.showBalance(a);
					System.out.println("Your balance is:"+d);
				}
			}catch(WalletException e) {
				System.out.println();
    			System.out.println("An error occured"+e.getMessage());
    			System.out.println();
			}
				
			}*/
			
		/*public void createAccount() {
			Customer request=new Customer();
			System.out.println("Enter the Name");
			request.setName(scan.nextLine());
			System.out.println("Enter the AccountType(Savings/Current)");
			request.setAccountType(scan.nextLine());
			System.out.println("Enter the Age");
			request.setAge(scan.nextLine());
			System.out.println("Enter the MobileNumber");
	        request.setMobileNo(scan.nextLine());
	        System.out.println("Enter the email Id");
	        request.setEmail(scan.nextLine());
	    	try {
	    		boolean result=walletService.validateCustomer(request);
	    		if(result) {
	    			long ret=walletService.createAccount(request);
	    			System.out.println("Customer with Id " +ret+ "added successfully");
	    		}
	    	}
	    		catch(WalletException e) {
	    			System.out.println();
	    			System.out.println("An error occured"+e.getMessage());
	    			System.out.println();
	    		}
	        }*/
		}

