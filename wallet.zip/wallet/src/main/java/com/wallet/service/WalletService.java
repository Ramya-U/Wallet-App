
	package com.wallet.service;


	import com.wallet.bean.Customer;
	import com.wallet.exception.WalletException;

	public interface WalletService {
	boolean checkAccountNo(long accountNo) throws WalletException;
	long createAccount(Customer request)throws WalletException;
	boolean validateCustomer(Customer request)throws WalletException;
	public double showBalance (Long accountNo) throws WalletException;
	double deposit(double b1,long getAccountNo) throws WalletException;
	double withdraw(double b1,long getAccountNo) throws WalletException;

	}


	