package org.cap.feedbackRest.service;

import java.util.List;

import org.cap.feedbackRest.model.FeedBack;



public interface FeedBackService {
	public List<FeedBack> getAll();

	public void save(FeedBack comment);

}
