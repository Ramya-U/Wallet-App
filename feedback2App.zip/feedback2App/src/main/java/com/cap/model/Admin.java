package com.cap.model;

import java.util.Date;




public class Admin {
	
	private int adminId;
	private String email;
	private String password;
	private Date lastLogin;



}
