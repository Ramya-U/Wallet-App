package org.cap.service;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountSevice {

void createAccount(Account account);

public List<Account> getAllAccounts(int custId);

public List<Account> getAccountWithBalance(int custId);

public Account findAccount(long accNo);

public void addTransaction(Transaction transaction);

void startTransaction(Transaction transaction);

public List<Transaction> getAllTransactions(Integer customerId);
}
