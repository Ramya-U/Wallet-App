package org.cap.dao;

import java.util.List;
import java.util.Map;

import org.cap.model.Account;

public interface IAccountDao {
	
	void createAccount(Account account);
	public List<Account> getAllAccounts(int customerId);
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId);

}
