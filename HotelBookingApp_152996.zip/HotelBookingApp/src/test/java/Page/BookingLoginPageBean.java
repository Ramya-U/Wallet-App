package Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BookingLoginPageBean {
	WebDriver driver;
	
	@FindBy(name="uname")
	private WebElement UserName;
	
	@FindBy(name="pwd")
	private WebElement Pwd;
	
	@FindBy(id="btn1")
	private WebElement Button;
	
	@FindBy(xpath="/html/body/h1")
	private WebElement pageheading;
	
	
	public BookingLoginPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	public String getPageTitle() {
		return pageheading.getText();
	}

	public void setSubmitLogin() {
		
		Button.submit();
	}
	public void setUserName(String uname) {

		UserName.sendKeys(uname);
	}

	public void setPassword(String pwd) {
		Pwd.sendKeys(pwd);
	}
	
	public void PaymentSuccess(String uname,String pwd) 
	{
		this.setUserName(uname);
		this.setPassword(pwd);
	}
}
