package Booking;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Page.BookingDetailsPageBean;
import Page.BookingLoginPageBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private BookingLoginPageBean loginBean;
	private BookingDetailsPageBean bookingBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
	
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		loginBean=new BookingLoginPageBean(driver);
		bookingBean=new BookingDetailsPageBean(driver);
	}
	
	
	@Given("^Login form$")
	public void login_form() throws Throwable {
	   driver.get("file:///D:/BDDWorkspace/HotelBookingApp/src/main/webapp/html/Login.html");
	}

	@When("^valid Login details$")
	public void valid_Login_details() throws Throwable {
		 //String pageHeading=loginBean.getPageTitle();
			
			//assertTrue(pageHeading.equals("Hotel booking Application"));
			WebElement element=driver.findElement(By.name("uname"));
			element.sendKeys("Capgemini");
			WebElement element1=driver.findElement(By.name("pwd"));
			element1.sendKeys("capg1234");
			//loginBean.PaymentSuccess("Capgemini","capg1234");
			WebElement element3=driver.findElement(By.id("btn1"));
			element3.click();
	}

	@Then("^Navigate to Booking Form$")
	public void navigate_to_Booking_Form() throws Throwable {
	    driver.get("file:///D:/BDDWorkspace/HotelBookingApp/src/main/webapp/html/Hotelbooking.html");
	}

	@Given("^Booking form$")
	public void booking_form() throws Throwable {
		driver.get("file:///D:/BDDWorkspace/HotelBookingApp/src/main/webapp/html/Hotelbooking.html");
	}

	@When("^valid Booking details$")
	public void valid_Booking_details() throws Throwable {
		//String pageHeading=loginBean.getPageTitle();
		
		//assertTrue(pageHeading.equals("Hotel booking Application"));
		
	
		bookingBean.loginTo_NextPage("Tom", "Jerry", "tom@gmail.com","1212121212","BharathiNagar", "Chennai", "Tamil Nadu","1","Tom","9876567867542345","333","09","1996");
	}

	@Then("^Navigate to Success Page$")
	public void navigate_to_Success_Page() throws Throwable {
	   driver.get("file:///D:/BDDWorkspace/HotelBookingApp/src/main/webapp/html/Success.html");
	}
	
	
	
	
	
	@After
	public void tearDown() {
	driver.close();
	}
	
}
