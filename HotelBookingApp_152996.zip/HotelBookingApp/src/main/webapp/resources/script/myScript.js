/*function validateBooking() {
    var x = document.forms["booking"]["fname"].value;
    var y = document.forms["booking"]["lname"].value;
    var z=document.forms["booking"]["mobile"].value;
    var ads=document.forms["booking"]["address"].value;
    var a = document.forms["booking"]["cname"].value;
    var b=document.forms["booking"]["cno"].value;
    var c=document.forms["booking"]["cvv"].value;
    var d=document.forms["booking"]["state"].value;
    var e=document.forms["booking"]["city"].value;
    var f=document.forms["booking"]["expyr"].value;
    var g=document.forms["booking"]["expmon"].value;
    var name4 = /^[A-Z]{2,}$/;
    var name5 = /^\d{16}$/;
    var name6 = /^\d{3}$/;
 
    var name1 = /^[A-Z][a-zA-Z]{2,}$/;
    var name3 = /^\d{10}$/;
    if (x = "") 
    {
    	alert("Please fill the first Name")
    	
    	 if (y = "") 
    	 {
    		 alert("Please fill the last name")
    		 if (z = "")
    		 {
    			 alert("Please fill the mobile number")
    			 
    			 if(ads="")
    			 {
    				 alert("Please fill the address")
    			 }
    				if(d="")
    				{
    					 alert("Please fill the state")
    				}
    				 if(e=""){
    					 alert("Please fill the city")
    				 }
    		    	if(a="")
    			    {
    		    		 alert("Please fill the Card holder name")
    			    }
    		    	if(b="")
    			    {
    		    		 alert("Please fill the Card  number")
    			    }
    		    	if(c="")
    			    {
    		    		 alert("Please fill the CVV Number")
    			    }
    		    	if(f="")
    			    {
    		    		 alert("Please fill the Expiry month")
    			    }
    		    	if(g="")
    			    {
    		    		 alert("Please fill the Expiry year")
    			    }
    			  if(x.match(name1))
    			  {
    				  if(y.match(name1))
    				  {
    					  if(z.match(name3))
    					  {
    						alert("Booking done successfully!!!!")
    						return true;
    						
    					  }
    					  else
    					  {
    						  alert("First Name must contain 3 characters with 1st capital letter"); return false; 
    					  }
    				  }
    				  else
    				  {
    			           alert("Last Name must contain 3 characters with 1st capital letter");return false;
    				  }
    		        	
    			  }
    			  else
    			  {
    				  alert("Mobile  number should be 10 digits");return false;
    			  }
    			 
    		 }
    			 
 
}*/

function validateLogin(){
	 var x1 = document.forms["booking"]["uname"].value;
	    var y1 = document.forms["booking"]["pwd"].value;
	    
	    if (x1 = "") 
	    {
	    	alert("Please fill the User Name")
	    }
	    	 if (y1 = "") 
	    	 {
	    		 alert("Please fill the Password")
}
	    	
	    	 }

