package org.cap.feedbackFront.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FeedbackController {

	@RequestMapping("/feedback1")
	public String mainPage() {
		
		return "feedback1";
	}
	
	
}
 