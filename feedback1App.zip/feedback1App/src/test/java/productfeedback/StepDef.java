package productfeedback;



import com.cap.model.FeedBack;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private FeedBack feedback;


	
	
    @Before
	public void setUp() {
		
	}
	
	@Given("^ProductPage$")
	public void productpage() throws Throwable {
	    
	}

	@Given("^Comment Textarea to enter Product feedback$")
	public void comment_Textarea_to_enter_Product_feedback() throws Throwable {
	   
	}

	@Given("^Star rating$")
	public void star_rating() throws Throwable {
	    
	}

	@When("^I enter product feedback$")
	public void i_enter_product_feedback() throws Throwable {
	  
	}

	@When("^product rating$")
	public void product_rating() throws Throwable {
	    
	}

	@When("^click submit$")
	public void click_submit() throws Throwable {
	  
	}

	@Then("^I display the product feedback$")
	public void i_display_the_product_feedback() throws Throwable {
	   
	}

	
	
	
}
