package createAccount;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.cg.exception.InvalidCustomer;
import com.cg.exception.InvalidOpeningBalance;
import com.cg.model.Address;
import com.cg.model.Customer;
import com.cg.service.IAccountService;

import cucumber.api.java.Before;

public class AccountTest {
private Customer customer;
private IAccountService accountService;
	@Before
	public void setUp() {
		Customer customer=new Customer();
		  customer.setFirstName("Tom");
		   customer.setLastName("Jerry");
		   Address address=new Address();
		   address.setDoorNo(11);
		   address.setCity("Chennai");
		   customer.setAddress(address);
	}	
	
	@Rule
	public ExpectedException exception=ExpectedException.none();
	
	@Test
	public void test_customer_with_null() throws InvalidCustomer, InvalidOpeningBalance{
		customer=null;
		exception.expect(InvalidCustomer.class);
		exception.expectMessage("Sorry! customer refers Null!!");
		accountService.createAccount(customer, 1000);
	}
	@Test
	public void when_invalid_opening_balance_throw_exception() throws InvalidCustomer, InvalidOpeningBalance {
		double amount=100;
		exception.expect(InvalidOpeningBalance.class);
		exception.expectMessage("Sorry");
		accountService.createAccount(customer, amount);
		
	}
}
