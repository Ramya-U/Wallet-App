package com.cg.service;



import com.cg.exception.InvalidCustomer;
import com.cg.exception.InvalidOpeningBalance;
import com.cg.model.Account;
import com.cg.model.Customer;

public class IAccountServiceImpl implements IAccountService {
Account account=new Account();
	@Override
	public Account createAccount(Customer customer, double amount) throws InvalidOpeningBalance, InvalidCustomer {
	if(customer!=null) {
		if(amount>=500) {
			Account account=new Account();
			account.setCustomer(customer);
			account.setOpeningBalance(amount);
			//account.setAccountNo(accountNo);
			return account;
		
	}else {
		throw new InvalidOpeningBalance("Sorry! balance insufficient");
	}
	}else{
		throw new InvalidCustomer("Sorry! Customer refers null");
	}
}
}
