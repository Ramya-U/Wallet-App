package com.cg.service;

import org.mockito.internal.stubbing.answers.ThrowsException;

import com.cg.exception.InvalidCustomer;
import com.cg.exception.InvalidOpeningBalance;
import com.cg.model.Account;
import com.cg.model.Customer;

public interface IAccountService {
public Account createAccount(Customer customer,double amount) throws InvalidOpeningBalance, InvalidCustomer ; 
	
}
