package com.cg.exception;

public class InvalidCustomer extends Exception {

	public InvalidCustomer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidCustomer(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
