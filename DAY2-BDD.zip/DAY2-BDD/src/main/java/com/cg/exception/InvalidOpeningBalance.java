package com.cg.exception;

public class InvalidOpeningBalance extends Exception {

	public InvalidOpeningBalance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidOpeningBalance(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
